console.log("connected")
//3 questions are live in this Variable
var questions = 3;
//Our 3 questions live in the array that is set to questionsLeft Variable.
var questionsLeft = ' [' + questions + ' questions left]';
//Prompt is gonna give our user something to interact with.
var adjective = prompt('Please type an adjective' + questionsLeft);
//We completed a task in the previous line of code, we now have 2 questions left
questions -= 1;
//The rest of our code now knows there are 2 questions remaining. 
questionsLeft = ' [' + questions + ' questions left]';
//Promting user with updated info
var verb = prompt('Please type a verb that does not end in -ing ' + questionsLeft);
//See above
questions -= 1;
//
questionsLeft = ' [' + questions + ' questions left]';
//
var noun = prompt('Please type a noun' + questionsLeft);
//
alert('All done. Ready for the message?');
//
var sentence = "<h2>There once was a " + adjective;
//
sentence += ' programmer who wanted to use JavaScript to ' + verb;
//
sentence += ' the ' + noun + '.</h2>';
//
document.write(sentence);